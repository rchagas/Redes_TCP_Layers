reset
javac ServerTransfer.java
javac ClientTransfer.java
java ServerTransfer &
java ClientTransfer
