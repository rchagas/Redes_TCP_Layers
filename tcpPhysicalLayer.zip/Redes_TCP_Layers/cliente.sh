reset
javac ClientTransfer.java
java ClientTransfer
