reset
javac ServerTransfer.java
java ServerTransfer
